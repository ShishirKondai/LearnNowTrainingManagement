ALTER TABLE "myfirstmodule$course" ADD CONSTRAINT "uniq_myfirstmodule$course_title" UNIQUE ("title");
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_myfirstmodule$course_title', '750c04ca-5d3c-481e-ab82-242354f4799c', 'fbcba739-3528-4556-990b-d73885a34d80');
ALTER TABLE "myfirstmodule$location" ADD CONSTRAINT "uniq_myfirstmodule$location_name" UNIQUE ("name");
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_myfirstmodule$location_name', 'ac71a242-33d6-4395-a4c8-f961e1f3f914', '26ee2a5b-50f6-41da-af24-1519cf60825c');
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20230715 14:38:35';
