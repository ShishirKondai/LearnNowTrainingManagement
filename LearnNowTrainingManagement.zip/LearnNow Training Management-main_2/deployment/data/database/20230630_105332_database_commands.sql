CREATE TABLE "myfirstmodule$course" (
	"id" BIGINT NOT NULL,
	"title" VARCHAR_IGNORECASE(200) NULL,
	"description" VARCHAR_IGNORECASE(200) NULL,
	"price" DECIMAL(28, 8) NULL,
	"duration" INT NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('750c04ca-5d3c-481e-ab82-242354f4799c', 'MyFirstModule.Course', 'myfirstmodule$course', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('fbcba739-3528-4556-990b-d73885a34d80', '750c04ca-5d3c-481e-ab82-242354f4799c', 'Title', 'title', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('a6dc6625-160e-4665-a80f-bf2824438e58', '750c04ca-5d3c-481e-ab82-242354f4799c', 'Description', 'description', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('203d2529-5b20-4cb7-bd9d-26e0795d22f3', '750c04ca-5d3c-481e-ab82-242354f4799c', 'Price', 'price', 5, 0, '0', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('2ebc266f-ad17-49d1-b5de-235acd5c17d7', '750c04ca-5d3c-481e-ab82-242354f4799c', 'Duration', 'duration', 3, 0, '0', false);
CREATE TABLE "myfirstmodule$location" (
	"id" BIGINT NOT NULL,
	"name" VARCHAR_IGNORECASE(200) NULL,
	"address" VARCHAR_IGNORECASE(200) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('ac71a242-33d6-4395-a4c8-f961e1f3f914', 'MyFirstModule.Location', 'myfirstmodule$location', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('26ee2a5b-50f6-41da-af24-1519cf60825c', 'ac71a242-33d6-4395-a4c8-f961e1f3f914', 'Name', 'name', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('c61ba0cf-baaa-42eb-a247-cf8aa9daee74', 'ac71a242-33d6-4395-a4c8-f961e1f3f914', 'Address', 'address', 30, 200, '', false);
CREATE TABLE "myfirstmodule$trainee" (
	"id" BIGINT NOT NULL,
	"name" VARCHAR_IGNORECASE(200) NULL,
	"address" VARCHAR_IGNORECASE(200) NULL,
	"emailaddress" VARCHAR_IGNORECASE(200) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('98485e20-08d6-4a96-8bd0-0749cac9a589', 'MyFirstModule.Trainee', 'myfirstmodule$trainee', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('fbeda20a-7688-4fc7-a9f4-4430e097c251', '98485e20-08d6-4a96-8bd0-0749cac9a589', 'Name', 'name', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('ac9a5f9f-a170-471a-a078-d2935d352e02', '98485e20-08d6-4a96-8bd0-0749cac9a589', 'Address', 'address', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('8950e379-d260-447b-9e74-1d983615b1a6', '98485e20-08d6-4a96-8bd0-0749cac9a589', 'EmailAddress', 'emailaddress', 30, 200, '', false);
CREATE TABLE "myfirstmodule$teacher" (
	"id" BIGINT NOT NULL,
	"name" VARCHAR_IGNORECASE(200) NULL,
	"emailaddress" VARCHAR_IGNORECASE(200) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('9273a097-3451-459b-bcc0-92079afd5e05', 'MyFirstModule.Teacher', 'myfirstmodule$teacher', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('64e1cd6a-912b-4626-bd08-e64d2aad9f86', '9273a097-3451-459b-bcc0-92079afd5e05', 'Name', 'name', 30, 200, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('558d2420-3388-4c47-a8af-b2f0b9f9431d', '9273a097-3451-459b-bcc0-92079afd5e05', 'EmailAddress', 'emailaddress', 30, 200, '', false);
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20230630 10:53:32';
