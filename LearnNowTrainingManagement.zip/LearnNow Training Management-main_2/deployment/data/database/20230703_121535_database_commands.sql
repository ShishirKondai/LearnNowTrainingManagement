CREATE TABLE "myfirstmodule$registration" (
	"id" BIGINT NOT NULL,
	"number" BIGINT NULL,
	"date" TIMESTAMP NULL,
	"attended" BOOLEAN NULL,
	PRIMARY KEY("id"));
CREATE SEQUENCE "myfirstmodule$registration_number_mxseq" AS BIGINT START WITH 1;
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('fa1a09ac-1189-41c6-acd8-a682d8eb3198', 'MyFirstModule.Registration', 'myfirstmodule$registration', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('41e2c153-ebb1-4f6a-b4ab-411340823631', 'fa1a09ac-1189-41c6-acd8-a682d8eb3198', 'Number', 'number', 0, 0, '1', true);
INSERT INTO "mendixsystem$sequence" ("attribute_id", "name", "start_value", "current_value") VALUES ('41e2c153-ebb1-4f6a-b4ab-411340823631', 'myfirstmodule$registration_number_mxseq', 1, 0);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('6c099c28-d0d6-409f-9f3c-0ce508201e41', 'fa1a09ac-1189-41c6-acd8-a682d8eb3198', 'Date', 'date', 20, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('389aadcc-e314-4dbd-b8a2-0822ed504a8f', 'fa1a09ac-1189-41c6-acd8-a682d8eb3198', 'Attended', 'attended', 10, 0, 'false', false);
CREATE TABLE "myfirstmodule$registration_trainingevent" (
	"myfirstmodule$registrationid" BIGINT NOT NULL,
	"myfirstmodule$trainingeventid" BIGINT NOT NULL,
	PRIMARY KEY("myfirstmodule$registrationid","myfirstmodule$trainingeventid"),
	CONSTRAINT "uniq_myfirstmodule$registration_trainingevent_myfirstmodule$registrationid" UNIQUE ("myfirstmodule$registrationid"));
CREATE INDEX "idx_myfirstmodule$registration_trainingevent_myfirstmodule$trainingevent_myfirstmodule$registration" ON "myfirstmodule$registration_trainingevent" ("myfirstmodule$trainingeventid" ASC,"myfirstmodule$registrationid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name") VALUES ('598889a9-00e5-4377-98a0-0b655a73e851', 'MyFirstModule.Registration_TrainingEvent', 'myfirstmodule$registration_trainingevent', 'fa1a09ac-1189-41c6-acd8-a682d8eb3198', 'bc021d7f-efc2-4f95-bc11-ca98bb9870ed', 'myfirstmodule$registrationid', 'myfirstmodule$trainingeventid', 'idx_myfirstmodule$registration_trainingevent_myfirstmodule$trainingevent_myfirstmodule$registration');
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_myfirstmodule$registration_trainingevent_myfirstmodule$registrationid', '598889a9-00e5-4377-98a0-0b655a73e851', '41da02d3-c499-3884-a121-427c3bf3979a');
CREATE TABLE "myfirstmodule$registration_trainee" (
	"myfirstmodule$registrationid" BIGINT NOT NULL,
	"myfirstmodule$traineeid" BIGINT NOT NULL,
	PRIMARY KEY("myfirstmodule$registrationid","myfirstmodule$traineeid"),
	CONSTRAINT "uniq_myfirstmodule$registration_trainee_myfirstmodule$registrationid" UNIQUE ("myfirstmodule$registrationid"));
CREATE INDEX "idx_myfirstmodule$registration_trainee_myfirstmodule$trainee_myfirstmodule$registration" ON "myfirstmodule$registration_trainee" ("myfirstmodule$traineeid" ASC,"myfirstmodule$registrationid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name") VALUES ('271fbf3d-d205-485f-b662-da2ceb121f83', 'MyFirstModule.Registration_Trainee', 'myfirstmodule$registration_trainee', 'fa1a09ac-1189-41c6-acd8-a682d8eb3198', '98485e20-08d6-4a96-8bd0-0749cac9a589', 'myfirstmodule$registrationid', 'myfirstmodule$traineeid', 'idx_myfirstmodule$registration_trainee_myfirstmodule$trainee_myfirstmodule$registration');
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_myfirstmodule$registration_trainee_myfirstmodule$registrationid', '271fbf3d-d205-485f-b662-da2ceb121f83', 'f62c6b8c-608f-3f46-8c3c-7dcc700f3f13');
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20230703 12:15:35';
