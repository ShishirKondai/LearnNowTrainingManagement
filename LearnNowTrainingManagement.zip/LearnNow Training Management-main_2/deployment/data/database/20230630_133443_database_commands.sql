CREATE TABLE "myfirstmodule$trainingevent" (
	"id" BIGINT NOT NULL,
	"startdate" TIMESTAMP NULL,
	"enddate" TIMESTAMP NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", "entity_name", "table_name", "remote", "remote_primary_key") VALUES ('bc021d7f-efc2-4f95-bc11-ca98bb9870ed', 'MyFirstModule.TrainingEvent', 'myfirstmodule$trainingevent', false, false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('5a2137a6-3ce1-480c-af02-b8e73abeb1c2', 'bc021d7f-efc2-4f95-bc11-ca98bb9870ed', 'StartDate', 'startdate', 20, 0, '', false);
INSERT INTO "mendixsystem$attribute" ("id", "entity_id", "attribute_name", "column_name", "type", "length", "default_value", "is_auto_number") VALUES ('ba3c952b-f659-4f76-a508-2cd5f7b56d20', 'bc021d7f-efc2-4f95-bc11-ca98bb9870ed', 'EndDate', 'enddate', 20, 0, '', false);
CREATE TABLE "myfirstmodule$trainingevent_teacher" (
	"myfirstmodule$trainingeventid" BIGINT NOT NULL,
	"myfirstmodule$teacherid" BIGINT NOT NULL,
	PRIMARY KEY("myfirstmodule$trainingeventid","myfirstmodule$teacherid"),
	CONSTRAINT "uniq_myfirstmodule$trainingevent_teacher_myfirstmodule$trainingeventid" UNIQUE ("myfirstmodule$trainingeventid"));
CREATE INDEX "idx_myfirstmodule$trainingevent_teacher_myfirstmodule$teacher_myfirstmodule$trainingevent" ON "myfirstmodule$trainingevent_teacher" ("myfirstmodule$teacherid" ASC,"myfirstmodule$trainingeventid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name") VALUES ('c1a28060-3b52-49df-93b0-f96cb195699b', 'MyFirstModule.TrainingEvent_Teacher', 'myfirstmodule$trainingevent_teacher', 'bc021d7f-efc2-4f95-bc11-ca98bb9870ed', '9273a097-3451-459b-bcc0-92079afd5e05', 'myfirstmodule$trainingeventid', 'myfirstmodule$teacherid', 'idx_myfirstmodule$trainingevent_teacher_myfirstmodule$teacher_myfirstmodule$trainingevent');
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_myfirstmodule$trainingevent_teacher_myfirstmodule$trainingeventid', 'c1a28060-3b52-49df-93b0-f96cb195699b', '2028d4aa-c459-39a1-bb5a-9cfc608a236a');
CREATE TABLE "myfirstmodule$trainingevent_location" (
	"myfirstmodule$trainingeventid" BIGINT NOT NULL,
	"myfirstmodule$locationid" BIGINT NOT NULL,
	PRIMARY KEY("myfirstmodule$trainingeventid","myfirstmodule$locationid"),
	CONSTRAINT "uniq_myfirstmodule$trainingevent_location_myfirstmodule$trainingeventid" UNIQUE ("myfirstmodule$trainingeventid"));
CREATE INDEX "idx_myfirstmodule$trainingevent_location_myfirstmodule$location_myfirstmodule$trainingevent" ON "myfirstmodule$trainingevent_location" ("myfirstmodule$locationid" ASC,"myfirstmodule$trainingeventid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name") VALUES ('9332a8b1-6ffa-4642-be49-98d85d1399e2', 'MyFirstModule.TrainingEvent_Location', 'myfirstmodule$trainingevent_location', 'bc021d7f-efc2-4f95-bc11-ca98bb9870ed', 'ac71a242-33d6-4395-a4c8-f961e1f3f914', 'myfirstmodule$trainingeventid', 'myfirstmodule$locationid', 'idx_myfirstmodule$trainingevent_location_myfirstmodule$location_myfirstmodule$trainingevent');
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_myfirstmodule$trainingevent_location_myfirstmodule$trainingeventid', '9332a8b1-6ffa-4642-be49-98d85d1399e2', 'a87e4f3b-b0c8-3e4d-99a8-1979402f85b2');
CREATE TABLE "myfirstmodule$trainingevent_course" (
	"myfirstmodule$trainingeventid" BIGINT NOT NULL,
	"myfirstmodule$courseid" BIGINT NOT NULL,
	PRIMARY KEY("myfirstmodule$trainingeventid","myfirstmodule$courseid"),
	CONSTRAINT "uniq_myfirstmodule$trainingevent_course_myfirstmodule$trainingeventid" UNIQUE ("myfirstmodule$trainingeventid"));
CREATE INDEX "idx_myfirstmodule$trainingevent_course_myfirstmodule$course_myfirstmodule$trainingevent" ON "myfirstmodule$trainingevent_course" ("myfirstmodule$courseid" ASC,"myfirstmodule$trainingeventid" ASC);
INSERT INTO "mendixsystem$association" ("id", "association_name", "table_name", "parent_entity_id", "child_entity_id", "parent_column_name", "child_column_name", "index_name") VALUES ('c2e8b0e7-e8f1-454b-8b3c-56d10aa4d296', 'MyFirstModule.TrainingEvent_Course', 'myfirstmodule$trainingevent_course', 'bc021d7f-efc2-4f95-bc11-ca98bb9870ed', '750c04ca-5d3c-481e-ab82-242354f4799c', 'myfirstmodule$trainingeventid', 'myfirstmodule$courseid', 'idx_myfirstmodule$trainingevent_course_myfirstmodule$course_myfirstmodule$trainingevent');
INSERT INTO "mendixsystem$unique_constraint" ("name", "table_id", "column_id") VALUES ('uniq_myfirstmodule$trainingevent_course_myfirstmodule$trainingeventid', 'c2e8b0e7-e8f1-454b-8b3c-56d10aa4d296', 'cc656b4c-699a-3be5-a203-36ffcf54455a');
UPDATE "mendixsystem$version" SET "versionnumber" = '4.2', "lastsyncdate" = '20230630 13:34:43';
