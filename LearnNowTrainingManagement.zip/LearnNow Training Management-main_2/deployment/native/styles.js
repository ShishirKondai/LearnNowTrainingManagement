import * as style0 from "C:/Users/prave/Mendix/LearnNow Training Management-main_2/themesource/administration/native/main";
import * as style1 from "C:/Users/prave/Mendix/LearnNow Training Management-main_2/themesource/nanoflowcommons/native/main";
import * as style2 from "C:/Users/prave/Mendix/LearnNow Training Management-main_2/themesource/webactions/native/main";
import * as style3 from "C:/Users/prave/Mendix/LearnNow Training Management-main_2/themesource/atlas_core/native/main";
import * as style4 from "C:/Users/prave/Mendix/LearnNow Training Management-main_2/themesource/myfirstmodule/native/main";
import * as style5 from "C:/Users/prave/Mendix/LearnNow Training Management-main_2/theme/native/main";

import { flatten } from "mendix/native";

module.exports = flatten([style0, style1, style2, style3, style4, style5]);
