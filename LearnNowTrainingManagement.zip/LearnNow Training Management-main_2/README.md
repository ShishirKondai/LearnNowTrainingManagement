# Blank Web App

House of [Blank Web App](https://marketplace.mendix.com/link/component/51830)

For collaboration with Atlas or Widgets, please visit [Widgets Resources](https://github.com/mendix/widgets-resources)