import * as variables from "../../../theme/native/custom-variables";

